# webCoRE
webCoRE is a web version of CoRE
