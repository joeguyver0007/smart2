#!/bin/sh

rm components.min.css
cat 0* >> components.min.css
cat 1* >> components.min.css
