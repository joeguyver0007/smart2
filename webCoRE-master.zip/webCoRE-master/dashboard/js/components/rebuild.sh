#!/bin/sh

rm components.min.js
cat 0* >> components.min.js
cat 1* >> components.min.js
cat 2* >> components.min.js
cat 3* >> components.min.js
